# Grouped Sample Data Functional Tests

The Functional Test Module for **Magento GroupedSampleData** module.
