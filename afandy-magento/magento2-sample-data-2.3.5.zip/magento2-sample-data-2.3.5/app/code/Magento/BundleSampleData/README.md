Magento_BundleSampleData module consists of installation scripts and fixtures.
